﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DotNetAssignment
{
    //1.	Write a program in C# to display a message as follows: “Welcome to the world of C#”
    class Program
    {
        static void Main(string[] args)
        {
            String str = "“Welcome to the world of C#";
            Console.WriteLine(str);
            Console.ReadKey();
        }
    }
}
