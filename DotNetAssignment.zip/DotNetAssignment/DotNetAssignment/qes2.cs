﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DotNetAssignment
{
    //2.	Write a program in C# to accept the name of the user as a command line argument and greet the user as:
	//“Hi! username
    //Welcome to the world of C#”

    class qes2
    {
        static void Main(String[] args)
        {
            string username;
            Console.WriteLine("enter username");
             username = Console.ReadLine();
            Console.WriteLine("Hi {0}", username);
            string content = @"Welcome to the world of c#";
            Console.WriteLine(content);
            Console.ReadKey();
        }
    }
}
