﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DotNetAssignment
{
    //3.	Write a program in C# to accept two numbers as command line argument and 
    //display all the numbers between the given two numbers.
    class qes3
    {
        public static void Main(String[] args)
        {
            int x, y;
            Console.WriteLine("enter first number");
            x = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("enter 2nd number");
            y = Convert.ToInt32(Console.ReadLine());
          
  
            for(int i=x;i<y;i++)
            {
                Console.WriteLine(i);
       
            }
            Console.ReadKey();
            }
        }
    }

