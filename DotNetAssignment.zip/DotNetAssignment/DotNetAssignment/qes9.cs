﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DotNetAssignment
{
    //9.Write a program in C# to generate a Fibonacci series till 40.
    class qes9
    {
        static void Main(string[] args)
        {
            int i, count=7, f1 = 0, f2 = 1, f3 = 0;
            Console.WriteLine(f1);
            Console.WriteLine(f2);
            for (i = 0; i <= count; i++)
            {
                f3 = f1 + f2;
                Console.WriteLine(f3);
                f1 = f2;
                f2 = f3;
            }
            Console.ReadLine();
            Console.ReadKey();

        }
    }
}


