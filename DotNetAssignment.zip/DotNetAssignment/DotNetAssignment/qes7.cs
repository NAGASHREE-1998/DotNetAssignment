﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DotNetAssignment
{
    //7.	Write a program to print the series: 0,1,4,9,16,.....625
    class qes7
    {
        public static void Main(string[] args)
        {
            for(int i=0; i<=25;i++)
            {
                Console.WriteLine("\n" + i * i);
            }
            Console.ReadKey();
        }
    }
}
