﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DotNetAssignment
{  //15.	Write a program in C# to accept ten marks and display the following
    //a.Total
    //b.Average
   // c.Minimum marks
    //d.Maximum marks
   // e.Display marks in ascending order
   // f.Display marks in descending order

    class qes15
    {
        public static int Total(List<int> markList)
        {
            int total = 0;
            foreach (int result in markList)
            {
                total = +result;
            }
            return total;
        }
        public static void Main()
        {
            Console.WriteLine("enter 10 marks");
            List<int> markList = new List<int>();
            for (int loopIndex = 0; loopIndex < 10; loopIndex++)
            {
                markList.Add(Convert.ToInt32(Console.ReadLine()));
            }
            Console.WriteLine("Total is " + Total(markList));
            Console.WriteLine("Average is" + Total(markList) / 10);
            markList.Sort();
            Console.WriteLine(markList[0] + "is the minimum mark");
            Console.WriteLine(markList[markList.Count - 1] + "is the maximum mark");
            Console.WriteLine("mark in ascending order");
            foreach (int result in markList)
            {
                Console.Write(result + " ");
            }
            markList.Reverse();
            Console.WriteLine("Mark in Desending order");
            foreach (int result in markList)
            {
                Console.Write(result + " ");
            }
            Console.ReadKey();
        }
    }
}
