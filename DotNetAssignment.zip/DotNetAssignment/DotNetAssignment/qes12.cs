﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DotNetAssignment
{
    //12.Write a program to print the numbers divisible by 7 between 200 and 300.
    class qes12
    {
        public static void Main()
        {
            int i;
            Console.WriteLine("numbers between 200 and 300, divisible by 7:\n");
            for (i = 201; i < 300; i++)
            {
                if (i % 7 == 0)
                {
                    Console.WriteLine("{0}", i);
                    Console.ReadKey();
                }
            }
        }
    }
}
    
