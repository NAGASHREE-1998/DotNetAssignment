﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DotNetAssignment
{
    //14.	Write a program in C# to find the smallest of five numbers accepted from the user.
    class qes14
    {
        public static void Main(string[] arg)
        {
            int[] arr1 = new int[5];
            int i, min, n = 5;
          
            Console.WriteLine("Input 5 elements in the array :\n", n);
            for (i = 0; i < 5; i++)
            {
                Console.WriteLine("element - {0} : ", i);
                arr1[i] = Convert.ToInt32(Console.ReadLine());
            }

            min = arr1[0];

            for (i = 1; i < 5; i++)
            {

                if (arr1[i] < min)
                {
                    min = arr1[i];
                }
            }
          
            Console.WriteLine("Minimum element is : {0}", min);
            Console.ReadLine();

        }
    }
}
 
