﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DotNetAssignment
{ //16.	Write a program in C# to accept a word from the user and display the length of it.
    class qes16
    {

        public static void Main()
        {
            string str; 
            int l = 0;
            Console.WriteLine("Input the string : ");
            str = Console.ReadLine();

            foreach (char chr in str)
            {
                l += 1;

            }

            Console.WriteLine("Length of the string is : {0}\n\n", l);
            Console.ReadKey();
        }
    }
}
