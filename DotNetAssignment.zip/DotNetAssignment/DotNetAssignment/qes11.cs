﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DotNetAssignment
{
    //11.	Write a program in C# to find the multiplication table of the given number till 20.
    class qes11
    {
        public static void Main(string[] args) 
        {
            int j, n;
            Console.WriteLine("Display the multiplication table:");
            Console.WriteLine("Input the number (Table to be calculated) : ");
            n = Convert.ToInt32(Console.ReadLine());
            for (j = 1; j <= 20; j++)
            {
                Console.WriteLine("{0} X {1} = {2}", n, j, n * j);
                Console.ReadLine();
                   
            }
        }
    }
}
