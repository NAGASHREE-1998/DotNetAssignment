﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DotNetAssignment
{
    //18.	Write a program in C# to accept two words from user and find out if they are same.
    class qes18
    {
        public static void Main()
        {

            // Get the strings which is to be checked 
          
            Console.WriteLine("Enter the first string: ");
            String string1 = Console.ReadLine();

            // Get the strings which is to be checked 
           
            Console.WriteLine("Enter the second string :");
            String string2 = Console.ReadLine();

            Console.WriteLine("\nAre both strings same: ");

            if (string1.Equals(string2) == true)
            {
                Console.WriteLine("Yes");
                Console.ReadKey();
            }
            else
            {
                Console.WriteLine("No");
                Console.ReadKey();
            }
        }
    }
}
