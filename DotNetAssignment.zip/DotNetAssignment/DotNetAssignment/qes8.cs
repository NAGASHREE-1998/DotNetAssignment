﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DotNetAssignment
{
    //8.	Write a program in C# to find the factorial of the given number.
    class qes8
    {
        public static void Main(string[] args)
        {
            int i, fact = 1, number;
            Console.WriteLine("Enter any Number: ");
            number = int.Parse(Console.ReadLine());
            for (i = 1; i <= number; i++)
            {
                fact = fact * i;
            }
            Console.WriteLine("Factorial of " + number + " is: " + fact);
            Console.ReadKey();
        }
    }
}

